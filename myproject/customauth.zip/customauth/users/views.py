from django.contrib.auth.views import LoginView,LogoutView
from django.shortcuts import redirect, render
from django.views.generic import TemplateView,CreateView,View
from django.urls import reverse_lazy
from .models import CustomUser
from .forms import CustomUserCreationForm
from django.contrib.auth import authenticate, login



class ProfileView(TemplateView):
    template_name = 'myser/profile.html'


class CustomSignupView(CreateView):
    model = CustomUser
    form_class = CustomUserCreationForm
    template_name = 'myser/signup.html'
    success_url = reverse_lazy('login')


class CustomUserLoginView(View):
    template_name = 'myser/login.html'

    def get(self, request, *args, **kwargs):
        return render(request, self.template_name)

    def post(self, request, *args, **kwargs):
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, email=email, password=password)
        if user is not None:
            login(request, user)
            return redirect(reverse_lazy('profile'))  # Replace 'profile' with your profile URL name
        else:
            # Handle invalid login here (e.g., display error message)
            return render(request, self.template_name, {'error': 'Invalid credentials'})

class UserLogoutView(LogoutView):
    next_page = reverse_lazy('login')
